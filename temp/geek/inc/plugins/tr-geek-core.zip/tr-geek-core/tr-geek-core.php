<?php
/**
* Plugin Name: Geek Core
* Plugin URI: https://plugins.themeregion.com/geek
* Description: Core functionalities of Geek theme depends on this plugin.
* Version:  1.1
* Author: ThemeRegion Team
* Author URI: http://themeregion.com/
* License:  GPL2
*/

// Define Constants
defined( 'GK_ROOT' ) or define( 'GK_ROOT', dirname( __FILE__ ) );
defined( 'GK_DIR' ) or define( 'GK_DIR',  plugin_dir_url( __FILE__ ) );
defined( 'GK_URI' ) or define( 'GK_URI', get_template_directory_uri() );
defined( 'GK_VERSION' ) or define( 'GK_VERSION', '1.0' );

if ( ! class_exists( 'TR_Geek_Core' ) ) {

	class TR_Geek_Core {

		public function __construct() {
			$this->geek_load_theme_backbone();
			$this->geek_load_shortcodes();
			$this->geek_core_load_textdomain();
			add_action( 'admin_head', array( $this, 'geek_admin_scripts' ) );

		}
		public function geek_load_theme_backbone() {
			require_once GK_ROOT . '/libs/cmb2-icon-picker/cmb2-fontawesome-picker.php';
			require_once GK_ROOT . '/libs/menu-icons/menu-icons.php';
		}

		public function geek_load_shortcodes() {

			if ( class_exists( 'Vc_Manager' ) ) {
				require_once GK_ROOT . '/vc-elements/vc-mapping.php';
				require_once GK_ROOT . '/vc-elements/vc-shortcode.php';
			}

		}

		public function geek_admin_scripts() {
			wp_enqueue_style( 'geek-admin-style', GK_DIR . 'assets/admin.styles.css' );
			wp_enqueue_style( 'font-awesome', get_template_directory_uri() . '/assets/css/font-awesome.min.css' );
		}

		/**
		 * Load plugin textdomain.
		 */
		function geek_core_load_textdomain() {
		  	load_plugin_textdomain( 'geek', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
		}

	}

	$core = new TR_Geek_Core;
	//$core->geek_core_load_textdomain();
	//$core->geek_load_theme_backbone();
	//$core->geek_load_shortcodes();
}
