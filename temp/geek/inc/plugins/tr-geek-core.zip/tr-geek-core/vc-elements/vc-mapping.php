<?php
$pre_text = 'GEEK ';

// disable full scren
vc_add_param( 'vc_row' , array(
    "type"       => "checkbox",
    "heading"    => esc_html__("Enable Container", 'geek'),
    "param_name" => "enable_full_screen",
    "value"      => array( esc_html__("Yes", 'geek') => 'yes') ,
));
vc_add_param( 'vc_row' , array(
    "type"       => "checkbox",
    "heading"    => esc_html__("Enable Default Padding For Section", 'geek'),
    "param_name" => "enable_padding",
    "value"      => array( esc_html__("Yes", 'geek') => 'yes') ,
));
//About Section
vc_map( array(
   "name" => esc_html__($pre_text."About Section", 'geek'),
   "base" => "geek_about_section",
   "class" => "",
   "icon" => "icon-st",
   "category" => 'by GEEK',
   "params" => array(        
        array(
            'type' => 'textfield',
            'value' => '',
            'heading' => esc_html__(' Title ', 'geek' ),
            'param_name' => 'about_title',
        ),
        array(
            'type' => 'colorpicker',
            'heading' => esc_html__( 'Title Text Color', 'geek' ),
            'param_name' => 'custom_title_color',
            "value"       => "#000",
        ),
        array(
            'type' => 'textfield',
            'value' => '',
            'heading' => esc_html__('Nickname Label', 'geek' ),
            'param_name' => 'nickname_label',
        ),
        array(
            'type' => 'textfield',
            'value' => '',
            'heading' => esc_html__('Nickname', 'geek' ),
            'param_name' => 'nickname',
        ),
        array(
            'type' => 'textfield',
            'value' => '',
            'heading' => esc_html__('Email Label', 'geek' ),
            'param_name' => 'email_label',
        ),
        array(
            'type' => 'textfield',
            'value' => '',
            'heading' => esc_html__('Email', 'geek' ),
            'param_name' => 'email',
        ),
        array(
            'type' => 'textfield',
            'value' => '',
            'heading' => esc_html__('Phone Label', 'geek' ),
            'param_name' => 'phone_label',
        ),
        array(
            'type' => 'textfield',
            'value' => '',
            'heading' => esc_html__('Phone', 'geek' ),
            'param_name' => 'phone',
        ),
        array(
            'type' => 'textfield',
            'value' => '',
            'heading' => esc_html__('Date of Birth Label', 'geek' ),
            'param_name' => 'dob_label',
        ),
        array(
            'type' => 'textfield',
            'value' => '',
            'heading' => esc_html__('Date of Birth', 'geek' ),
            'param_name' => 'date_of_birth',
        ),
        array(
            'type' => 'textfield',
            'value' => '',
            'heading' => esc_html__('Address Label', 'geek' ),
            'param_name' => 'add_label',
        ),
        array(
            'type' => 'textfield',
            'value' => '',
            'heading' => esc_html__('Address', 'geek' ),
            'param_name' => 'address',
        ),
        array(
            'type' => 'textfield',
            'value' => '',
            'heading' => esc_html__('Signature', 'geek' ),
            'param_name' => 'signature',
        ),
        array(
            'type' => 'textarea_html',
            'heading' => __( 'Content',  'geek'  ),
            'param_name' => 'content',
            'value' => '',
            "description" => __( "Enter your content here.", 'geek' ),
        ),
        array(
            'heading' => __('Achievements', 'geek'),
            'type' => 'param_group',
            'group' => 'Achievements',
            'value' => '',
            'param_name' => 'achievements',
            'params' => array(
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Counter', 'geek' ),
                    'param_name' => 'counter',
                    "value"       => "",
                    "description" => esc_html__("Enter a Number", 'geek')
                ),
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Achievement Title', 'geek' ),
                    'param_name' => 'achievement_title',
                    "value"       => "",
                    "description" => esc_html__( "Enter A Title", 'geek' )
                ),
                array(
                    'type' => 'colorpicker',
                    'heading' => esc_html__( 'Counter Color', 'geek' ),
                    'param_name' => 'counter_color',
                    "value"       => "#000",
                ),
                array(
                    'type' => 'colorpicker',
                    'heading' => esc_html__( 'Achievement Text Color', 'geek' ),
                    'param_name' => 'achievement_text_color',
                    "value"       => "#000",
                ),
            ),
        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__( 'Extra CSS Class', 'geek' ),
            'param_name' => 'custom_css_class',
            "value"       => "",
        ),
    )
));


///GEEK Progress Bar
vc_map( array(
   "name" => esc_html__($pre_text."Skills", 'geek'),
   "base" => "geek_skills",
   "class" => "",
   "icon" => "icon-st",
   "category" => 'by GEEK',
   "params" => array(        
        array(
            'type' => 'dropdown',
            'heading' => esc_html__( 'Progress Bar Style', 'geek' ),
            'param_name' => 'bar_style',
            'value' => array(
                __( 'Select a style', 'geek' ) => 'none',
                __( 'Bar Style',  'geek'  ) => 'bar',
                __( 'Chart',  'geek'  ) => 'chart',
            ),
        ),
        array(
            'heading' => __('Skills Content ', 'geek'),
            'type' => 'param_group',
            'value' => '',
            'param_name' => 'skills_content',
            'params' => array(
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Rating Value', 'geek' ),
                    'param_name' => 'bar_value',
                    "value"       => "",
                    "description" => esc_html__("Enter a Number for rating ( 1-100 ). Exp. 90,85", 'geek')
                ),
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Title', 'geek' ),
                    'param_name' => 'bar_title',
                    "value"       => "",
                    "description" => esc_html__( "Enter A Title", 'geek' )
                ),
                array(
                    'type' => 'colorpicker',
                    'heading' => esc_html__( 'Bar Color', 'geek' ),
                    'param_name' => 'bar_color',
                    "value"       => "#000",
                ),
                array(
                    'type' => 'colorpicker',
                    'heading' => esc_html__( 'Title Text Color', 'geek' ),
                    'param_name' => 'bar_text_color',
                    "value"       => "#000",
                ),
            ),
        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__( 'Extra CSS Class', 'geek' ),
            'param_name' => 'custom_css_class',
            "value"       => "",
        ),
    )
));

 //GEEK TITLE
vc_map( array(
   "name" => esc_html__($pre_text."Custom Title", 'geek'),
   "base" => "geek_custom_title",
   "class" => "",
   "icon" => "icon-st",
   "category" => 'by GEEK',
   "params" => array(
        array(
            'type' => 'dropdown',
            'heading' => __( 'Select Heading Type',  'geek'  ),
            'param_name' => 'heading_type',
            'value' => array(
                __( 'None',  'geek'  ) => 'none',
                __( 'Image',  'geek'  ) => 'media',
                __( 'Icon',  'geek'  ) => 'titleicon',
            ),
        ),
        array(
           'type' => 'attach_image',
           'heading' => esc_html__( 'Image', 'geek' ),
           'param_name' => 'banner_bg',
           "value"       => "",
           "description" => esc_html__("Upload image for title", 'geek' ),
           'dependency' => array(
                'element' => 'heading_type',
                'value' => 'media',
            ),
        ),
        array(
            'type' => 'iconpicker',
            'heading' => esc_html__( 'Icons', 'geek' ),
            'param_name' => 'title_icon',
            "value"       => '',
            'settings'    => array(
                'emptyIcon' => false,
                'iconsPerPage' => 200,
            ),
            'dependency' => array(
                'element' => 'heading_type',
                'value' => array('titleicon'),
            ),
        ),
        array(
            'type' => 'textfield',
            'value' => '',
            'heading' => esc_html__(' Title ', 'geek' ),
            'param_name' => 'title_page',
        ),
        array(
            'type' => 'colorpicker',
            'heading' => esc_html__( 'Title Text Color', 'geek' ),
            'param_name' => 'custom_title_color',
            "value"       => "#000",
        ),
        array(
            'type' => 'dropdown',
            'heading' => __( 'Title Alignment',  'geek'  ),
            'param_name' => 'text_position',
            'value' => array(
                __( 'Select a position',  'geek'  ) => 'none',
                __( 'Left',  'geek'  ) => 'left',
                __( 'Right',  'geek'  ) => 'right',
                __( 'Center',  'geek'  ) => 'center',
            ),
            "description" => __( "Select a position.", 'geek' ),
        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__( 'Extra CSS Class', 'geek' ),
            'param_name' => 'custom_css_class',
            "value"       => "",
        ),
    )
));

//EXPERIENCE 
vc_map( array(
   "name" => esc_html__($pre_text."Experience Information", 'geek'),
   "base" => "geek_experience",
   "class" => "",
   "icon" => "icon-st",
   "category" => 'by GEEK',
   "params" => array(
        array(
            'heading' => __('Experience Information', 'geek'),
            'type' => 'param_group',
            'value' => '',
            'param_name' => 'experience_content',
            'params' => array(
                array(
                   'type' => 'attach_image',
                   'heading' => esc_html__( 'Image', 'geek' ),
                   'param_name' => 'company_logo',
                   "value"       => "",
                   "description" => esc_html__("Upload a company logo. Image size 170x160 px.", 'geek' ),
                ),
                array(
                    'type' => 'textfield',
                    'value' => '',
                    'heading' => esc_html__('Job Designation', 'geek' ),
                    'param_name' => 'job_designation',
                ),
                array(
                    'type' => 'textfield',
                    'value' => '',
                    'heading' => esc_html__('Job Time (From)', 'geek' ),
                    'param_name' => 'job_from_time',
                ),
                array(
                    'type' => 'textfield',
                    'value' => '',
                    'heading' => esc_html__('Job Time (To)', 'geek' ),
                    'param_name' => 'job_to_time',
                ),
                array(
                    'type' => 'textfield',
                    'value' => '',
                    'heading' => esc_html__('Total Experience', 'geek' ),
                    'param_name' => 'job_total_experience',
                ),
                array(
                    'type' => 'textarea',
                    'value' => '',
                    'heading' => esc_html__('Job Responsibilities', 'geek' ),
                    'param_name' => 'job_responsibility',
                ),
                array(
                    'type' => 'colorpicker',
                    'heading' => esc_html__( 'Text Color', 'geek' ),
                    'param_name' => 'custom_text_color',
                    "value"       => "#000",
                ),
            ),
        ),        
        array(
            'type' => 'textfield',
            'heading' => esc_html__( 'Extra CSS Class', 'geek' ),
            'param_name' => 'custom_css_class',
            "value"       => "",
        ),
    )
));

//EXPERIENCE 
vc_map( array(
   "name" => esc_html__($pre_text."Education Information", 'geek'),
   "base" => "geek_education",
   "class" => "",
   "icon" => "icon-st",
   "category" => 'by GEEK',
   "params" => array(
        array(
            'heading' => __('Education Information', 'geek'),
            'type' => 'param_group',
            'value' => '',
            'param_name' => 'education_content',
            'params' => array(
                array(
                   'type' => 'attach_image',
                   'heading' => esc_html__( 'Image', 'geek' ),
                   'param_name' => 'university_logo',
                   "value"       => "",
                   "description" => esc_html__("Upload your School/College/University/Institute logo. Image size 230x70 px.", 'geek' ),
                ),
                array(
                    'type' => 'textfield',
                    'value' => '',
                    'heading' => esc_html__('Institute Name', 'geek' ),
                    'param_name' => 'institute_name',
                ),
                array(
                    'type' => 'textfield',
                    'value' => '',
                    'heading' => esc_html__('Subject', 'geek' ),
                    'param_name' => 'subject',
                ),
                array(
                    'type' => 'textfield',
                    'value' => '',
                    'heading' => esc_html__('Duration ( Passing Years)', 'geek' ),
                    'param_name' => 'duration',
                ),
                array(
                    'type' => 'textarea',
                    'value' => '',
                    'heading' => esc_html__('Details', 'geek' ),
                    'param_name' => 'course_details',
                ),
                array(
                    'type' => 'colorpicker',
                    'heading' => esc_html__( 'Text Color', 'geek' ),
                    'param_name' => 'custom_text_color',
                    "value"       => "#000",
                ),
            ),
        ),        
        array(
            'type' => 'textfield',
            'heading' => esc_html__( 'Extra CSS Class', 'geek' ),
            'param_name' => 'custom_css_class',
            "value"       => "",
        ),
    )
));

//RECENT WORKS
vc_map( array(
   "name" => esc_html__($pre_text."Portfolio", 'geek'),
   "base" => "geek_portfolio",
   "class" => "",
   "icon" => "icon-st",
   "category" => 'by GEEK',
   "params" => array(
        array(
            'type' => 'dropdown',
            'heading' => __( 'Column',  'geek'  ),
            'param_name' => 'portfolio_column',
            'value' => array(
                __( 'Select Column',  'geek'  ) => 'none',
                __( '2 Column',  'geek'  ) => '2',
                __( '3 Column',  'geek'  ) => '3',
            ),
            "description" => __( "Select a position.", 'geek' ),
        ),
        array(
            'heading' => __('Portfolio', 'geek'),
            'type' => 'param_group',
            'value' => '',
            'param_name' => 'portfolio_content',
            'params' => array(
                array(
                   'type' => 'attach_image',
                   'heading' => esc_html__( 'Image', 'geek' ),
                   'param_name' => 'portfolio_image',
                   "value"       => "",
                   "description" => esc_html__("Upload your image. Image size 360x264 px.", 'geek' ),
                ),
                array(
                    'type' => 'textfield',
                    'value' => '',
                    'heading' => esc_html__('Title', 'geek' ),
                    'param_name' => 'portfolio_title',
                ),
                array(
                    'type' => 'textfield',
                    'value' => '',
                    'heading' => esc_html__('Portfolio Url', 'geek' ),
                    'param_name' => 'portfolio_link',
                ),
                array(
                    'type' => 'textfield',
                    'value' => '',
                    'heading' => esc_html__('Portfolio Category', 'geek' ),
                    'param_name' => 'portfolio_category',
                ),
                array(
                    'type' => 'colorpicker',
                    'heading' => esc_html__( 'Text Color', 'geek' ),
                    'param_name' => 'custom_text_color',
                    "value"       => "#000",
                ),
                array(
                    'type' => 'colorpicker',
                    'heading' => esc_html__( 'Image Hover Overlay Color', 'geek' ),
                    'param_name' => 'custom_image_overlay_color',
                    "value"       => "#EF6E30",
                ),
            ),
        ),        
        array(
            'type' => 'textfield',
            'heading' => esc_html__( 'Extra CSS Class', 'geek' ),
            'param_name' => 'custom_css_class',
            "value"       => "",
        ),
    )
));

//Contact Information
vc_map( array(
   "name" => esc_html__($pre_text."Contact Information", 'geek'),
   "base" => "geek_contact_info",
   "class" => "",
   "icon" => "icon-st",
   "category" => 'by GEEK',
   "params" => array(
        array(
            'type' => 'iconpicker',
            'heading' => esc_html__( 'Address Icon', 'geek' ),
            'param_name' => 'add_icon',
            "value"       => '',
            'settings'    => array(
                'emptyIcon' => false,
                'iconsPerPage' => 200,
            ),
            'dependency' => array(
                'element' => 'type',
                'value' => 'fontawesome',
            ),
        ),
        array(
            'type' => 'colorpicker',
            'heading' => esc_html__( 'Icon Color', 'geek' ),
            'param_name' => 'add_icon_color',
            "value"       => "",
        ),
        array(
            'type' => 'textfield',
            'value' => '',
            'heading' => esc_html__('Address Label', 'geek' ),
            'param_name' => 'add_label',
        ),
        array(
            'type' => 'textfield',
            'value' => '',
            'heading' => esc_html__('Address', 'geek' ),
            'param_name' => 'address',
        ),
        array(
            'type' => 'iconpicker',
            'heading' => esc_html__( 'Mobile Icon', 'geek' ),
            'param_name' => 'mobile_icon',
            "value"       => '',
            'settings'    => array(
                'emptyIcon' => false,
                'iconsPerPage' => 200,
            ),
            'dependency' => array(
                'element' => 'type',
                'value' => 'fontawesome',
            ),
        ),
        array(
            'type' => 'colorpicker',
            'heading' => esc_html__( 'Icon Color', 'geek' ),
            'param_name' => 'mob_icon_color',
            "value"       => "",
        ),
        array(
            'type' => 'textfield',
            'value' => '',
            'heading' => esc_html__('Mobile Label', 'geek' ),
            'param_name' => 'mobile_label',
        ),
        array(
            'type' => 'textfield',
            'value' => '',
            'heading' => esc_html__('Mobile number', 'geek' ),
            'param_name' => 'mobile_number',
        ),
        array(
            'type' => 'iconpicker',
            'heading' => esc_html__( 'Email Icon', 'geek' ),
            'param_name' => 'email_icon',
            "value"       => '',
            'settings'    => array(
                'emptyIcon' => false,
                'iconsPerPage' => 200,
            ),
            'dependency' => array(
                'element' => 'type',
                'value' => 'fontawesome',
            ),
        ),
        array(
            'type' => 'colorpicker',
            'heading' => esc_html__( 'Email Icon Color', 'geek' ),
            'param_name' => 'email_icon_color',
            "value"       => "",
        ),
        array(
            'type' => 'textfield',
            'value' => '',
            'heading' => esc_html__('Email Label', 'geek' ),
            'param_name' => 'email_label',
        ),
        array(
            'type' => 'textfield',
            'value' => '',
            'heading' => esc_html__('Email address', 'geek' ),
            'param_name' => 'contact_email',
        ),
        array(
            'type' => 'iconpicker',
            'heading' => esc_html__( 'Social Profile Icon', 'geek' ),
            'param_name' => 'sp_icon',
            "value"       => '',
            'settings'    => array(
                'emptyIcon' => false,
                'iconsPerPage' => 200,
            ),
            'dependency' => array(
                'element' => 'type',
                'value' => 'fontawesome',
            ),
        ),
        array(
            'type' => 'colorpicker',
            'heading' => esc_html__( 'Social Profile Icon Color', 'geek' ),
            'param_name' => 'sp_icon_color',
            "value"       => "",
        ),
        array(
            'type' => 'textfield',
            'value' => '',
            'heading' => esc_html__('Social Profile Label', 'geek' ),
            'param_name' => 'sp_label',
        ),
        array(
            'heading' => __( 'Social profiles', 'geek' ),
            'type'  => 'param_group',
            'value' => '',
            'param_name' => 'social_profile',
            'params' => array(
                array(
                    'type' => 'iconpicker',
                    'heading' => esc_html__( 'Social Icon', 'geek' ),
                    'param_name' => 'icon_fontawesome',
                    "value"       => '',
                    'settings'    => array(
                        'emptyIcon' => false,
                        'iconsPerPage' => 200,
                    ),
                    'dependency' => array(
                        'element' => 'type',
                        'value' => 'fontawesome',
                    ),
                ),
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Social Link', 'geek' ),
                    'param_name' => 'social_link',
                    "value"       => "",
                    "description" => esc_html__( "Enter your social link.", 'geek' )
                ),
                array(
                    'type' => 'colorpicker',
                    'heading' => esc_html__( 'Icon Color', 'geek' ),
                    'param_name' => 'social_icon_color',
                    "value"       => "#2D3038",
                ),  
            ),
        ),
        array(
            'type' => 'colorpicker',
            'heading' => esc_html__( 'Text Color', 'geek' ),
            'param_name' => 'custom_text_color',
            "value"       => "#000",
        ),            
        array(
            'type' => 'textfield',
            'heading' => esc_html__( 'Extra CSS Class', 'geek' ),
            'param_name' => 'custom_css_class',
            "value"       => "",
        ),
    )
));

//Contact Form 
vc_map( array(
   "name" => esc_html__($pre_text."Contact Form", 'geek'),
   "base" => "geek_contact_form",
   "class" => "",
   "icon" => "icon-st",
   "category" => 'by GEEK',
   "params" => array(
        array(
            'type' => 'textfield',
            'value' => '',
            'heading' => esc_html__('Title', 'geek' ),
            'param_name' => 'contact_form_title',
        ),
        array(
            'type' => 'textarea',
            'value' => '',
            'heading' => esc_html__('Description', 'geek' ),
            'param_name' => 'contact_form_description',
        ),
        array(
            'type' => 'textarea_html',
            'value' => '',
            'heading' => esc_html__('Contact Form Shortcode', 'geek' ),
            'param_name' => 'content',
            "description" => esc_html__( "Enter your contact form shortcode. Exp. [contact-form-7 id=\"1804\" title=\"Contact form 1\"] ", 'geek' )
        ),
        array(
            'type' => 'colorpicker',
            'heading' => esc_html__( 'Text Color', 'geek' ),
            'param_name' => 'custom_text_color',
            "value"       => "#000",
        ),            
        array(
            'type' => 'textfield',
            'heading' => esc_html__( 'Extra CSS Class', 'geek' ),
            'param_name' => 'custom_css_class',
            "value"       => "",
        ),
    )
));

//RECENT BLOG
vc_map( array(
   "name" => esc_html__($pre_text."Recent Blog", 'geek'),
   "base" => "geek_recent_blog",
   "class" => "",
   "icon" => "icon-st",
   "category" => 'by GEEK',
   "params" => array(
          array(
           'type' => 'textfield',
           'heading' => esc_html__( 'Number of Posts', 'geek' ),
           'param_name' => 'number_of_post',
           "value"       => "3",
           "description" => esc_html__("Enter # of posts You want to show", 'geek')
        ), 
    ),
));

//RESUME
vc_map( array(
   "name" => esc_html__($pre_text."Resume", 'geek'),
   "base" => "geek_resume",
   "class" => "",
   "icon" => "icon-st",
   "category" => 'by GEEK',
   "params" => array(
        array(
           'type' => 'attach_image',
           'heading' => esc_html__( 'Picture', 'geek' ),
           'param_name' => 'resume_picture',
           'group'  => 'Profile',
           "value"       => '',
           "description" => esc_html__("Upload your profile image. Dimensions 151x181.", 'geek')
        ),
        array(
            'type' => 'textfield',
            'value' => '',
            'group'  => 'Profile',
            'heading' => esc_html__('Name', 'geek' ),
            'param_name' => 'resume_name',
        ),
        array(
            'type' => 'textfield',
            'value' => '',
            'group'  => 'Profile',
            'heading' => esc_html__('Occupation', 'geek' ),
            'param_name' => 'resume_occupation',
        ),
        array(
            'type' => 'textfield',
            'value' => '',
            'group'  => 'Profile',
            'heading' => esc_html__('Address', 'geek' ),
            'param_name' => 'resume_address',
        ),
        array(
            'type' => 'textfield',
            'value' => '',
            'group'  => 'Profile',
            'heading' => esc_html__('Mobile number', 'geek' ),
            'param_name' => 'resume_mobile',
        ),
        array(
            'type' => 'textfield',
            'value' => '',
            'group'  => 'Profile',
            'heading' => esc_html__('Email address', 'geek' ),
            'param_name' => 'resume_email',
        ),
        array(
            'type' => 'iconpicker',
            'heading' => esc_html__( 'Icon', 'geek' ),
            'param_name' => 'co_icon',
            'group'  => 'Career Objective',
            "value"       => '',
            'settings'    => array(
                'emptyIcon' => false,
                'iconsPerPage' => 200,
            ),
            'dependency' => array(
                'element' => 'type',
                'value' => 'fontawesome',
            ),
        ),
        array(
            'type' => 'colorpicker',
            'group'  => 'Career Objective',
            'heading' => esc_html__( 'Icon Color', 'geek' ),
            'param_name' => 'co_icon_color',
            "value"       => "",
        ),
        array(
            'type' => 'textfield',
            'group'  => 'Career Objective',
            'heading' => esc_html__( 'Label', 'geek' ),
            'param_name' => 'co_label',
            "value"       => "",
        ),
        array(
            'type' => 'textarea',
            'value' => '',
            'group'  => 'Career Objective',
            'heading' => esc_html__('Career Objective', 'geek' ),
            'param_name' => 'resume_cobjective',
        ),
        array(
            'type' => 'iconpicker',
            'heading' => esc_html__( 'Icon', 'geek' ),
            'param_name' => 'wh_icon',
            'group'  => 'Work History',
            "value"       => '',
            'settings'    => array(
                'emptyIcon' => false,
                'iconsPerPage' => 200,
            ),
            'dependency' => array(
                'element' => 'type',
                'value' => 'fontawesome',
            ),
        ),
        array(
            'type' => 'colorpicker',
            'group'  => 'Work History',
            'heading' => esc_html__( 'Icon Color', 'geek' ),
            'param_name' => 'wh_icon_color',
            "value"       => "",
        ),
        array(
            'type' => 'textfield',
            'group'  => 'Work History',
            'heading' => esc_html__( 'Label', 'geek' ),
            'param_name' => 'wh_label',
            "value"       => "",
        ),
        array(
            'heading' => __( 'Work History', 'geek' ),
            'type'  => 'param_group',
            'group'  => 'Work History',
            'value' => '',
            'param_name' => 'resume_work_history',
            'params' => array(
                array(
                    'type' => 'textfield',
                    'value' => '',
                    'heading' => esc_html__('Job Designation', 'geek' ),
                    'param_name' => 'job_designation',
                ),
                array(
                    'type' => 'textfield',
                    'value' => '',
                    'heading' => esc_html__('Job Time (From)', 'geek' ),
                    'param_name' => 'job_from_time',
                ),
                array(
                    'type' => 'textfield',
                    'value' => '',
                    'heading' => esc_html__('Job Time (To)', 'geek' ),
                    'param_name' => 'job_to_time',
                ),
                array(
                    'type' => 'textarea',
                    'value' => '',                    
                    'heading' => esc_html__('Job Responsibilities', 'geek' ),
                    'param_name' => 'job_responsibility',
                ),
            ),
        ),
        array(
            'type' => 'iconpicker',
            'heading' => esc_html__( 'Icon', 'geek' ),
            'param_name' => 'eb_icon',
            'group'  => 'Educational Background',
            "value"       => '',
            'settings'    => array(
                'emptyIcon' => false,
                'iconsPerPage' => 200,
            ),
            'dependency' => array(
                'element' => 'type',
                'value' => 'fontawesome',
            ),
        ),
        array(
            'type' => 'colorpicker',
            'group'  => 'Educational Background',
            'heading' => esc_html__( 'Icon Color', 'geek' ),
            'param_name' => 'eb_icon_color',
            "value"       => "",
        ),
        array(
            'type' => 'textfield',
            'group'  => 'Educational Background',
            'heading' => esc_html__( 'Label', 'geek' ),
            'param_name' => 'eb_label',
            "value"       => "",
        ),
        array(
            'heading' => __( 'Educational Background', 'geek' ),
            'type'  => 'param_group',
            'group'  => 'Educational Background',
            'value' => '',
            'param_name' => 'resume_education',
            'params' => array(
                array(
                    'type' => 'textfield',
                    'value' => '',                    
                    'heading' => esc_html__('Subject with Institute Name', 'geek' ),
                    'param_name' => 'institute_name',
                ),
                array(
                    'type' => 'textfield',
                    'value' => '',
                    'heading' => esc_html__('Duration ( Passing Years)', 'geek' ),
                    'param_name' => 'duration',
                ),
            ),
        ),
        array(
            'type' => 'iconpicker',
            'heading' => esc_html__( 'Icon', 'geek' ),
            'param_name' => 'lp_icon',
            'group'  => 'Language Proficiency',
            "value"       => '',
            'settings'    => array(
                'emptyIcon' => false,
                'iconsPerPage' => 200,
            ),
            'dependency' => array(
                'element' => 'type',
                'value' => 'fontawesome',
            ),
        ),
        array(
            'type' => 'colorpicker',
            'group'  => 'Language Proficiency',
            'heading' => esc_html__( 'Icon Color', 'geek' ),
            'param_name' => 'lp_icon_color',
            "value"       => "",
        ),
        array(
            'type' => 'textfield',
            'group'  => 'Language Proficiency',
            'heading' => esc_html__( 'Label', 'geek' ),
            'param_name' => 'lp_label',
            "value"       => "",
        ),
        array(
            'heading' => __('Language Proficiency', 'geek'),
            'type' => 'param_group',
            'value' => '',
            'group' => 'Language Proficiency',
            'param_name' => 'resume_language',
            'params' => array(
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Rating Value', 'geek' ),
                    'param_name' => 'bar_value',
                    "value"       => "",
                    "description" => esc_html__("Enter a Number for rating. Exp. 4, 4.5", 'geek')
                ),
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Title', 'geek' ),
                    'param_name' => 'bar_title',
                    "value"       => "",
                    "description" => esc_html__( "Enter A Title", 'geek' )
                ),
            ),
        ),
        array(
            'type' => 'iconpicker',
            'heading' => esc_html__( 'Icon', 'geek' ),
            'param_name' => 'exp_icon',
            'group'  => 'Expertise',
            "value"       => '',
            'settings'    => array(
                'emptyIcon' => false,
                'iconsPerPage' => 200,
            ),
            'dependency' => array(
                'element' => 'type',
                'value' => 'fontawesome',
            ),
        ),
        array(
            'type' => 'colorpicker',
            'group'  => 'Expertise',
            'heading' => esc_html__( 'Icon Color', 'geek' ),
            'param_name' => 'exp_icon_color',
            "value"       => "",
        ),
        array(
            'type' => 'textfield',
            'group'  => 'Expertise',
            'heading' => esc_html__( 'Label', 'geek' ),
            'param_name' => 'exp_label',
            "value"       => "",
        ),
        array(
            'heading' => __('Expertise', 'geek'),
            'type' => 'param_group',
            'value' => '',
            'group' => 'Expertise',
            'param_name' => 'resume_expertise',
            'params' => array(
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Rating Value', 'geek' ),
                    'param_name' => 'expertise_value',
                    "value"       => "",
                    "description" => esc_html__("Enter a Number for rating (1-100). Exp. 80,90", 'geek')
                ),
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Title', 'geek' ),
                    'param_name' => 'expertise_title',
                    "value"       => "",
                    "description" => esc_html__( "Enter A Title", 'geek' )
                ),
            ),
        ),
        array(
            'type' => 'iconpicker',
            'heading' => esc_html__( 'Icon', 'geek' ),
            'param_name' => 'pr_icon',
            'group'  => 'Personal Info',
            "value"       => '',
            'settings'    => array(
                'emptyIcon' => false,
                'iconsPerPage' => 200,
            ),
            'dependency' => array(
                'element' => 'type',
                'value' => 'fontawesome',
            ),
        ),
        array(
            'type' => 'colorpicker',
            'group'  => 'Personal Info',
            'heading' => esc_html__( 'Icon Color', 'geek' ),
            'param_name' => 'pr_icon_color',
            "value"       => "",
        ),
        array(
            'type' => 'textfield',
            'group'  => 'Personal Info',
            'heading' => esc_html__( 'Label', 'geek' ),
            'param_name' => 'pr_label',
            "value"       => "",
        ),
        array(
            'heading' => __('Personal Info', 'geek'),
            'type' => 'param_group',
            'value' => '',
            'group' => 'Personal Info',
            'param_name' => 'resume_personal_info',
            'params' => array(
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Title', 'geek' ),
                    'param_name' => 'personal_info_title',
                    "value"       => "",
                    "description" => esc_html__( "Enter A Title", 'geek' )
                ),
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Description', 'geek' ),
                    'param_name' => 'personal_info_desc',
                    "value"       => "",
                    "description" => esc_html__( "Enter A Description", 'geek' )
                ),
            ),
        ),
        array(
            'type' => 'iconpicker',
            'heading' => esc_html__( 'Icon', 'geek' ),
            'param_name' => 'port_icon',
            'group'  => 'Portfolio',
            "value"       => '',
            'settings'    => array(
                'emptyIcon' => false,
                'iconsPerPage' => 200,
            ),
            'dependency' => array(
                'element' => 'type',
                'value' => 'fontawesome',
            ),
        ),
        array(
            'type' => 'colorpicker',
            'group'  => 'Portfolio',
            'heading' => esc_html__( 'Icon Color', 'geek' ),
            'param_name' => 'port_icon_color',
            "value"       => "",
        ),
        array(
            'type' => 'textfield',
            'group'  => 'Portfolio',
            'heading' => esc_html__( 'Label', 'geek' ),
            'param_name' => 'port_label',
            "value"       => "",
        ),
        array(
            'heading' => __('Portfolio', 'geek'),
            'type' => 'param_group',
            'value' => '',
            'group' => 'Portfolio',
            'param_name' => 'resume_portfolio',
            'params' => array(
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Portfolio Name', 'geek' ),
                    'param_name' => 'portfolio_title',
                    "value"       => "",
                ),
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Portfolio URL Title', 'geek' ),
                    'param_name' => 'portfolio_url_text',
                    "value"       => "",
                    "description" => esc_html__( "Enter A Description", 'geek' )
                ),
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Portfolio URL Link', 'geek' ),
                    'param_name' => 'portfolio_url_link',
                    "value"       => "#",
                    "description" => esc_html__( "Enter A Description", 'geek' )
                ),
            ),
        ),
        array(
            'type' => 'iconpicker',
            'heading' => esc_html__( 'Icon', 'geek' ),
            'param_name' => 'dec_icon',
            'group'  => 'Declaration',
            "value"       => '',
            'settings'    => array(
                'emptyIcon' => false,
                'iconsPerPage' => 200,
            ),
            'dependency' => array(
                'element' => 'type',
                'value' => 'fontawesome',
            ),
        ),
        array(
            'type' => 'colorpicker',
            'group'  => 'Declaration',
            'heading' => esc_html__( 'Icon Color', 'geek' ),
            'param_name' => 'dec_icon_color',
            "value"       => "",
        ),
        array(
            'type' => 'textfield',
            'group'  => 'Declaration',
            'heading' => esc_html__( 'Label', 'geek' ),
            'param_name' => 'dec_label',
            "value"       => "",
        ),
        array(
            'type' => 'textarea_html',
            'heading' => esc_html__( 'Declaration', 'geek' ),
            'param_name' => 'content',
            "value"       => "",
            'group'       => 'Declaration',
        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__( 'Signature', 'geek' ),
            'param_name' => 'resume_signature',
            "value"       => "",
            'group'       => 'Declaration',
        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__( 'Resume PDF Download URL', 'geek' ),
            'param_name' => 'resume_pdf',
            "value"       => "",
            'group'       => 'Declaration',
        ),

    ),
));