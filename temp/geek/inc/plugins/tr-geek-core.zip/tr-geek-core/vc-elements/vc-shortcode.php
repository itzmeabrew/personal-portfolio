<?php
// ABOUT SECTION
add_shortcode('geek_about_section', 'geek_about_section_sc');

function geek_about_section_sc($atts, $content = null){
    extract( $atts );
    $achievement = vc_param_group_parse_atts( $atts['achievements'] );
    ob_start();
?>
<div class="about-section <?php echo ( isset( $custom_css_class ) &&  $custom_css_class != "" ) ? esc_attr($custom_css_class) : " " ; ?>">
    <?php if( isset( $about_title ) && $about_title != "" ) : ?>
        <h1 style="color: <?php echo $custom_title_color; ?>"><?php echo esc_html($about_title); ?></h1>
    <?php endif; ?>
    <div class="about-info">
        <?php echo $content; ?>
        <div class="signature">
            <h1><?php echo ( $signature != "" ) ? esc_html($signature) : " " ; ?></h1>
        </div>
    </div>
    <address>
        <p><span><?php echo ( isset($nickname_label) && $nickname_label != '' ) ? esc_html( $nickname_label . ':' ) : esc_html__('Nick Name:', 'geek')  ?></span> <?php echo ( $nickname != "" ) ? esc_html($nickname) : " " ; ?></p>
        <p><span><?php echo ( isset($email_label) && $email_label != '' ) ? esc_html( $email_label . ':' ) : esc_html__('Email:', 'geek')  ?></span> <?php echo ( $email != "" ) ? esc_html($email) : " " ; ?></p>
        <p><span><?php echo ( isset($phone_label) && $phone_label != '' ) ? esc_html( $phone_label . ':' ) : esc_html__('Phone:', 'geek')  ?></span> <?php echo ( $phone != "" ) ? esc_html($phone) : " " ; ?></p>
        <p><span><?php echo ( isset($dob_label) && $dob_label != '' ) ? esc_html( $dob_label . ':' ) : esc_html__('Date of Birth:', 'geek')  ?></span> <?php echo ( $date_of_birth != "" ) ? esc_html($date_of_birth) : " " ; ?></p>
        <p><span><?php echo ( isset($add_label) && $add_label != '' ) ? esc_html( $add_label . ':' ) : esc_html__('Address:', 'geek')  ?></span> <?php echo ( $address != "" ) ? esc_html($address) : " " ; ?></p>
    </address>
    <ul class="achievement">
    <?php for( $i = 0; $i< sizeof($achievement); $i++):  ?>
        <li class="achievement-info">                        
            <span class="counter" style=" color:<?php echo ( $achievement[$i]['counter_color'] != "" ) ? $achievement[$i]['counter_color'] : " " ; ?> "><?php echo ( $achievement[$i]['counter'] != "" ) ? esc_html($achievement[$i]['counter']) : " " ; ?></span>
            <h4 style=" color:<?php echo ( $achievement[$i]['achievement_text_color'] != "" ) ? $achievement[$i]['achievement_text_color'] : " " ; ?> "><?php echo ( $achievement[$i]['achievement_title'] != "" ) ? esc_html($achievement[$i]['achievement_title']) : " " ; ?></h4>
    <?php endfor; ?>                           
    </ul>   
</div><!-- about section -->    
<?php  return ob_get_clean();
}

/// SKILLS SHORTCODE
add_shortcode('geek_skills', 'geek_skills_sc');

function geek_skills_sc($atts, $content = null){
    extract( $atts );
    $skills_bar = vc_param_group_parse_atts( $atts['skills_content'] );
    ob_start();
?>
    <?php if( $bar_style == 'bar' ): ?>
    <div class="skill-section progress-content <?php echo ( isset( $custom_css_class ) &&  $custom_css_class != "" ) ? esc_attr($custom_css_class) : " " ; ?>">
        <div class="">
        <?php for( $i = 0; $i< sizeof($skills_bar); $i++):  ?>
        <?php if( $i%2 == 0 ): ?>
            <div class="rating-bar bar-left">
        <?php else: ?> 
            <div class="rating-bar bar-right">
        <?php endif; ?>
            <label style=" color:<?php echo ( $skills_bar[$i]['bar_text_color'] != "" ) ? $skills_bar[$i]['bar_text_color'] : " " ; ?>"><?php echo ( $skills_bar[$i]['bar_title'] != "" ) ? esc_html($skills_bar[$i]['bar_title']) : " " ; ?></label>
            <span class="rating-count pull-right"><?php echo ( $skills_bar[$i]['bar_value'] != "" ) ? esc_html($skills_bar[$i]['bar_value']) : " " ; ?>%</span>
            <div class="skill-progress">
                <div class="progress">
                    <div class="progress-bar" role="progressbar" aria-valuenow="<?php echo ( $skills_bar[$i]['bar_value'] != "" ) ? esc_html($skills_bar[$i]['bar_value']) : " " ; ?>" aria-valuemin="0" aria-valuemax="100" style="background-color:<?php echo ( $skills_bar[$i]['bar_color'] != "" ) ? $skills_bar[$i]['bar_color'] : " " ; ?>">
                    </div>
                </div>
            </div>
            <?php if( $i%2 == 0 ): ?>
            </div>
        <?php else: ?>      
            </div>
        <?php endif; ?>
        <?php endfor; ?>
        </div>
    </div>
    <?php elseif( $bar_style == 'chart' ): ?>                           

    <div class=".skill-section language-skill <?php echo ( isset( $custom_css_class ) &&  $custom_css_class != "" ) ? esc_attr($custom_css_class) : " " ; ?>">
        <ul>
        <?php for( $i = 0; $i< sizeof($skills_bar); $i++):  ?>
            <li class="chart" data-percent="<?php echo ( $skills_bar[$i]['bar_value'] != "" ) ? esc_html($skills_bar[$i]['bar_value']) : " " ; ?>">
                <span class="percent" style="background-color:<?php echo ( $skills_bar[$i]['bar_color'] != "" ) ? $skills_bar[$i]['bar_color'] : " " ; ?>"></span>
                <h5 style=" color:<?php echo ( $skills_bar[$i]['bar_text_color'] != "" ) ? $skills_bar[$i]['bar_text_color'] : " " ; ?>"><?php echo ( $skills_bar[$i]['bar_title'] != "" ) ? esc_html($skills_bar[$i]['bar_title']) : " " ; ?></h5>
            </li>
        <?php endfor; ?>                                 
        </ul>
    </div><!-- more skill --> 
    <?php else: echo "No Data Found"; ?>
    <?php endif; ?>            
<?php  return ob_get_clean();
}

add_shortcode('geek_custom_title', 'geek_custom_title_sc');

function geek_custom_title_sc($atts, $content = null){
    extract(shortcode_atts(array(
        'title_page'            => '',
        'text_position'         => 'left',
        'custom_title_color'    => '',
        'banner_bg'             => '',
        'title_icon'             => '',
        'animation_duration'    => '',
        'animation_delay'       => '',
        'animation_style'       => '',
        'custom_css_class'      => '',
    ), $atts));
    ob_start();
    if( $text_position == 'center' ) $alignment = "text-center";
    elseif( $text_position == 'right' ) $alignment = "text-right";
    else $alignment = "text-left";
?>
    <div class="<?php echo $alignment; ?> section-title <?php echo ( isset( $custom_css_class ) &&  $custom_css_class != "" ) ? esc_attr($custom_css_class) : " " ; ?>">
        <?php if( $banner_bg != '' && !empty($banner_bg) ) :  ?>
            <?php $img = wp_get_attachment_image_src($atts['banner_bg'], 68, 69);  ?>
            <img src="<?php echo esc_url($img[0]); ?>" alt="Image" class="img-responsive">
        <?php elseif( $title_icon != '' && !empty( $title_icon )  ) : ?>
            <span class="title-icon" style="color: <?php echo esc_html( $custom_title_color ); ?>"><i class="<?php echo esc_html( $title_icon ); ?>"></i></span>
        <?php endif; ?>
        <h1 style="color: <?php echo $custom_title_color; ?>"><?php echo ( $title_page != "" ) ? esc_html($title_page) : " " ; ?></h1>
    </div>
<?php  return ob_get_clean();
}

/// EXPERIENCE SHORTCODE
add_shortcode('geek_experience', 'geek_experience_sc');

function geek_experience_sc($atts, $content = null){
    extract( $atts );    $experience_content = vc_param_group_parse_atts( $atts['experience_content'] );
    ob_start();
?>
<?php for( $i = 0; $i< sizeof($experience_content); $i++):  ?>
    <div class="exprience <?php echo ( isset( $custom_css_class ) && $custom_css_class != "" ) ? esc_attr($custom_css_class) : " " ; ?>">
        <div class="exprience-image">
            <?php $img = wp_get_attachment_image_src($experience_content[$i]['company_logo'], 170, 160);  ?>
            <img src="<?php echo esc_url($img[0]); ?>" alt="Image" class="img-responsive">
        </div>
        <div class="exprience-info">
            <h3 style="color: <?php echo $experience_content[$i]['custom_text_color']; ?>"><?php echo ( $experience_content[$i]['job_designation'] != "" ) ? esc_html($experience_content[$i]['job_designation']) : " " ; ?></h3>
            <h5 style="color: <?php echo $experience_content[$i]['custom_text_color']; ?>"><?php echo ( $experience_content[$i]['job_from_time'] != "" ) ? esc_html($experience_content[$i]['job_from_time']) : " " ; ?> - <?php echo ( $experience_content[$i]['job_to_time'] != "" ) ? esc_html($experience_content[$i]['job_to_time']) : " " ; ?> (<?php echo ( $experience_content[$i]['job_total_experience'] != "" ) ? esc_html($experience_content[$i]['job_total_experience']) : " " ; ?>)</h5>
            <p style="color: <?php echo $experience_content[$i]['custom_text_color']; ?>"><?php echo ( $experience_content[$i]['job_responsibility'] != "" ) ? esc_html($experience_content[$i]['job_responsibility']) : " " ; ?></p>
        </div>                            
    </div>
<?php endfor; ?>
<?php  return ob_get_clean();
}

/// EDUCATION SHORTCODE
add_shortcode('geek_education', 'geek_education_sc');

function geek_education_sc($atts, $content = null){
    extract( $atts );
    $education_content = vc_param_group_parse_atts( $atts['education_content'] );
    ob_start();
?>
<?php for( $i = 0; $i< sizeof($education_content); $i++):  ?>
    <div class="education-info <?php echo ( isset( $custom_css_class ) && $custom_css_class != "" ) ? esc_attr($custom_css_class) : " " ; ?>">
            <?php $img = wp_get_attachment_image_src($education_content[$i]['university_logo'], 230, 70);  ?>
            <img src="<?php echo esc_url($img[0]); ?>" alt="Image" class="img-responsive">
            <h3 style="color: <?php echo $education_content[$i]['custom_text_color']; ?>"><?php echo ( $education_content[$i]['institute_name'] != "" ) ? esc_html($education_content[$i]['institute_name']) : " " ; ?></h3>
            <h5 style="color: <?php echo $education_content[$i]['custom_text_color']; ?>"><?php echo ( $education_content[$i]['subject'] != "" ) ? esc_html($education_content[$i]['subject']) : " " ; ?></h5>
            <h6 style="color: <?php echo $education_content[$i]['custom_text_color']; ?>"><?php echo ( $education_content[$i]['duration'] != "" ) ? esc_html($education_content[$i]['duration']) : " " ; ?></h6>
            <p style="color: <?php echo $education_content[$i]['custom_text_color']; ?>"><?php echo ( $education_content[$i]['course_details'] != "" ) ? esc_html($education_content[$i]['course_details']) : " " ; ?></p>
    </div>
<?php endfor; ?>
<?php  return ob_get_clean();
}

/// PORTFOLIO SHORTCODE
add_shortcode('geek_portfolio', 'geek_portfolio_sc');

function geek_portfolio_sc($atts, $content = null){
    extract( $atts );
    $portfolio_content = vc_param_group_parse_atts( $atts['portfolio_content'] );
    ob_start();
?>
<div class="row">
<?php for( $i = 0; $i< sizeof($portfolio_content); $i++):  ?>  
    <?php if( $portfolio_column == '2' ):  ?>
    <div class="col-sm-6 <?php echo ( isset( $custom_css_class ) && $custom_css_class != "" ) ? esc_attr($custom_css_class) : " " ; ?>">
    <?php elseif( $portfolio_column == '3' ): ?>
        <div class="col-sm-4 <?php echo ( isset( $custom_css_class ) && $custom_css_class != "" ) ? esc_attr($custom_css_class) : " " ; ?>">
    <?php endif; ?>  
        <div class="portfolio-item">
            <?php $img = wp_get_attachment_image_src($portfolio_content[$i]['portfolio_image'], 360, 264);  ?>
            <img src="<?php echo esc_url($img[0]); ?>" alt="Image" class="img-responsive">
            <div class="portfolio-overlay" style="background-color: <?php echo ( isset($portfolio_content[$i]['custom_image_overlay_color']) && $portfolio_content[$i]['custom_image_overlay_color'] != "" ) ? esc_attr($portfolio_content[$i]['custom_image_overlay_color']) : " " ; ?> ">
                <div class="portfolio-info">
                    <a href="<?php echo esc_url($img[0]); ?>"><i class="fa fa-camera-retro" aria-hidden="true"></i></a>
                    <a href="<?php echo ( isset( $portfolio_content[$i]['portfolio_link'] ) && $portfolio_content[$i]['portfolio_link'] != "" ) ? esc_url($portfolio_content[$i]['portfolio_link']) : " " ; ?>"><h3 style="color: <?php echo ( isset( $portfolio_content[$i]['custom_text_color'] ) && $portfolio_content[$i]['custom_text_color'] != '') ? esc_attr( $portfolio_content[$i]['custom_text_color'] ) : ''; ?>"><?php echo ( $portfolio_content[$i]['portfolio_title'] != "" ) ? esc_html($portfolio_content[$i]['portfolio_title']) : " " ; ?></h3></a>
                    <p style="color: <?php echo ( isset( $portfolio_content[$i]['custom_text_color'] ) && $portfolio_content[$i]['custom_text_color'] != '') ? esc_attr( $portfolio_content[$i]['custom_text_color'] ) : ''; ?>"><?php echo ( $portfolio_content[$i]['portfolio_category'] != "" ) ? esc_html($portfolio_content[$i]['portfolio_category']) : " " ; ?></p>
                </div>
            </div>
        </div>
<?php if( $portfolio_column == '2' ):  ?>
    </div>
<?php elseif( $portfolio_column == '3' ): ?>
    </div>
<?php endif; ?>
<?php endfor; ?>
</div>
<?php  return ob_get_clean();
}

/// CONTACT INOFRMATION SHORTCODE
add_shortcode('geek_contact_info', 'geek_contact_info_sc');

function geek_contact_info_sc($atts, $content = null){
    extract( $atts );
    $social_profile = vc_param_group_parse_atts( $atts['social_profile'] );
    ob_start();
?>
<div class="contact-section address <?php echo ( isset( $custom_css_class ) && $custom_css_class != "" ) ? esc_attr($custom_css_class) : " " ; ?>">
    <ul>
        <li>
        <?php if( isset( $add_icon ) && $add_icon!= '' ): ?>
            <div class="icons" style="color: <?php echo ( isset( $add_icon_color ) && $add_icon_color != '') ? esc_attr( $add_icon_color ) : ''?>;">
                <i class="<?php echo esc_attr( $add_icon ); ?>" aria-hidden="true"></i>
            </div>
        <?php endif; ?>
        <?php if( isset( $address ) && $address != "" ) : ?>
            <?php echo ( isset($add_label) && $add_label != '' ) ? '<h3>' . esc_html( $add_label . ':' ) . '</h3>' : ''  ?>
            <p><?php echo esc_html($address); ?></p>
        <?php endif; ?>
        </li>
        <li>
        <?php if( isset( $mobile_icon ) && $mobile_icon!= '' ): ?>
            <div class="icons icons1" style="color: <?php echo ( isset( $mob_icon_color ) && $mob_icon_color != '') ? esc_attr( $mob_icon_color ) : ''?>;">
                <i class="<?php echo esc_attr( $mobile_icon ); ?>" aria-hidden="true"></i>
            </div>
        <?php endif; ?>
        <?php if( isset( $mobile_number ) && $mobile_number != "" ) : ?>
            <?php echo ( isset($mobile_label) && $mobile_label != '' ) ? '<h3>' .esc_html( $mobile_label . ':' ). '</h3>' : '';?>
            <p><?php echo esc_html( $mobile_number ); ?></p>
        <?php endif; ?>
        </li>
        <li>
            <?php if( isset( $email_icon ) && $email_icon!= '' ): ?>
                <div class="icons icons2" style="color: <?php echo ( isset( $email_icon_color ) && $email_icon_color != '') ? esc_attr( $email_icon_color ) : ''?>;">
                    <i class="<?php echo esc_attr( $email_icon ); ?>" aria-hidden="true"></i>
                </div>
            <?php endif; ?>
        <?php if( isset( $contact_email ) && $contact_email != "" ) : ?>
            <?php echo ( isset($email_label) && $email_label != '' ) ? '<h3>' . esc_html( $email_label . ':' ) . '</h3>' : '' ?>
            <a href="mailto:<?php echo esc_url( $contact_email ); ?>"><?php echo esc_html( $contact_email ); ?></a>
        <?php endif; ?>
        </li>
        <li>
            <?php if( isset( $sp_icon ) && $sp_icon!= '' ): ?>
                <div class="icons icons3" style="color: <?php echo ( isset( $sp_icon_color ) && $sp_icon_color != '') ? esc_attr( $sp_icon_color ) : ''?>;">
                    <i class="<?php echo esc_attr( $sp_icon ); ?>" aria-hidden="true"></i>
                </div>
            <?php endif; ?>
            <?php echo ( isset($sp_label) && $sp_label != '' ) ? '<h3>' . esc_html( $sp_label . ':' ) . '</h3>' : ''; ?>
            <ul class="social list-inline">
            <?php for( $i = 0; $i< sizeof($social_profile); $i++):  ?>
                <li><a href="<?php echo esc_url( $social_profile[$i]['social_link'] ); ?>" style="color: <?php echo ( isset( $social_profile[$i]['social_icon_color'] ) && $social_profile[$i]['social_icon_color'] != '') ? esc_attr( $social_profile[$i]['social_icon_color'] ) : ''; ?>" ><i class="<?php echo esc_attr( $social_profile[$i]['icon_fontawesome'] ); ?>"></i></a></li>
            <?php endfor; ?>
            </ul>
        </li>
    </ul>                            
</div>
<?php  return ob_get_clean();
}

/// CONTACT FORM SHORTCODE
add_shortcode('geek_contact_form', 'geek_contact_form_sc');

function geek_contact_form_sc($atts, $content = null){
    extract( $atts );
    ob_start();
?>
<div class="contact-section contact <?php echo ( isset( $custom_css_class ) && $custom_css_class != "" ) ? esc_attr($custom_css_class) : " " ; ?>">
    <div class="contact-info">
        <div class="title">
            <div class="icons">
                <i class="fa fa-commenting-o" aria-hidden="true"></i> 
            </div>                                
            <h3 style="color: <?php echo ( isset( $custom_text_color ) && $custom_text_color != '') ? esc_attr( $custom_text_color ) : ''; ?>"><?php echo ( $contact_form_title != '') ? esc_attr( $contact_form_title ) : ''; ?></h3>
        </div>                            
        <p style="color: <?php echo ( isset( $custom_text_color ) && $custom_text_color != '') ? esc_attr( $custom_text_color ) : ''; ?>"><?php echo ( $contact_form_description != '') ? esc_attr( $contact_form_description ) : ''; ?></p>
    </div>
    <?php if( $content != '') { echo do_shortcode( $content ); } ?>
</div>
<?php  return ob_get_clean();
}

//Recent Blog Shortcode

add_shortcode('geek_recent_blog', 'geek_recent_blog_shortcode');

function geek_recent_blog_shortcode($atts , $content = null){
    extract( $atts );
    ob_start();
?>
<div class="row">
<?php
    $q = new WP_Query( array('post_type' => 'post','posts_per_page' => $number_of_post ) ); 
        while( $q->have_posts() ) : 
            $q->the_post();       
            global $post;
    ?>
        <div id="post-<?php the_ID(); ?>" class="col-sm-6">
            <div class="entry-post">
                <div class="entry-thumbnail">
                    <div class="thumbnail-oberlay"></div>
                    <?php if( has_post_thumbnail() ) : ?>
                    <?php $url_thumbpost = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), '360', '264' ); ?>
                        <img width="<?php echo esc_attr( $url_thumbpost[1] ); ?>" height="<?php echo esc_attr( $url_thumbpost[2] ); ?>" class="img-responsive" src="<?php echo esc_url( $url_thumbpost[0] ); ?>" alt="<?php the_title(); ?>">
                    <?php endif; ?>
                </div>
                <div class="post-content">
                    <?php geek_blog_time(); ?>
                    <?php
                    if ( is_single() ) :
                        the_title( '<h2 class="entry-title">', '</h2>' );
                    else :
                        the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );
                    endif;
                    ?>
                </div>
            </div>
        </div><!-- #post-## -->
<?php endwhile; ?>
</div>
<?php wp_reset_query();
return ob_get_clean();
}

/// RESUME SHORTCODE
add_shortcode('geek_resume', 'geek_resume_sc');

function geek_resume_sc($atts, $content = null){
    extract( $atts );    
    $resume_work_history = vc_param_group_parse_atts( $atts['resume_work_history'] );
    $resume_education = vc_param_group_parse_atts( $atts['resume_education'] );
    $resume_language = vc_param_group_parse_atts( $atts['resume_language'] );
    $resume_expertise = vc_param_group_parse_atts( $atts['resume_expertise'] );
    $resume_personal_info = vc_param_group_parse_atts( $atts['resume_personal_info'] );
    $resume_portfolio = vc_param_group_parse_atts( $atts['resume_portfolio'] );
    ob_start();
?>
<div class="profile-section section-content">
    <div class="profile-logo">
        <?php $img = wp_get_attachment_image_src($resume_picture, 151, 181);  ?>
        <img src="<?php echo esc_url($img[0]); ?>" alt="Image" class="img-responsive">
    </div>
    <div class="profile-info">
        <h1><?php echo ( $resume_name != "" ) ? esc_html($resume_name) : " " ; ?></h1>
        <h4><?php echo ( $resume_occupation != "" ) ? esc_html($resume_occupation) : " " ; ?></h4>
        <address>
            <p>Address: <?php echo ( $resume_address != "" ) ? esc_html($resume_address) : " " ; ?> <br> Phone: <?php echo ( $resume_mobile != "" ) ? esc_html($resume_mobile) : " " ; ?> <br> <a href="mailto:<?php echo ( $resume_email != "" ) ? esc_url($resume_email) : " " ; ?>">Email: <?php echo ( $resume_email != "" ) ? esc_html($resume_email) : " " ; ?></a></p>
        </address>
    </div><!-- profile info -->
    <div class="career-objective">
        <div class="title">
            <?php if( isset( $co_icon ) && $co_icon!= '' ): ?>
                <div class="icons" style="color: <?php echo ( isset( $co_icon_color ) && $co_icon_color != '') ? esc_attr( $co_icon_color ) : ''?>;">
                    <i class="<?php echo esc_attr( $co_icon ); ?>" aria-hidden="true"></i>
                </div>
            <?php endif; ?>                                  
            <?php echo ( isset($co_label) && $co_label != '' ) ? '<h3>' . esc_html( $co_label . ':' ) . '</h3>' : ''; ?>
       </div> 
        <div class="sub-content">
            <p><?php echo ( $resume_cobjective != '' ) ? esc_html($resume_cobjective) : '' ?></p>
        </div>
    </div><!-- career objective -->
    <hr>
    <div class="work-history">
        <div class="title">
            <?php if( isset( $wh_icon ) && $wh_icon!= '' ): ?>
                <div class="icons" style="color: <?php echo ( isset( $wh_icon_color ) && $wh_icon_color != '') ? esc_attr( $wh_icon_color ) : ''?>;">
                    <i class="<?php echo esc_attr( $wh_icon ); ?>" aria-hidden="true"></i>
                </div>
            <?php endif; ?>                                  
            <?php echo ( isset($wh_label) && $wh_label != '' ) ? '<h3>' . esc_html( $wh_label . ':' ) . '</h3>' : ''; ?>
        </div>
        <div class="sub-content">
        <?php for( $i = 0; $i< sizeof($resume_work_history); $i++):  ?>
            <div class="history">
                <h5><?php echo ( $resume_work_history[$i]['job_designation'] != '' ) ? esc_html($resume_work_history[$i]['job_designation']) : '' ?></h5>
                <h6><?php echo ( $resume_work_history[$i]['job_from_time'] != '' ) ? esc_html($resume_work_history[$i]['job_from_time']) : '' ?> - <?php echo ( $resume_work_history[$i]['job_to_time'] != '' ) ? esc_html($resume_work_history[$i]['job_to_time']) : '' ?></h6>
                <p><?php echo ( $resume_work_history[$i]['job_responsibility'] != '' ) ? esc_html($resume_work_history[$i]['job_responsibility']) : '' ?></p>
            </div>
            <?php if( $i < sizeof($resume_work_history)-1 ): ?>
                    <hr>
            <?php endif;?>
        <?php endfor; ?>
        </div>
    </div><!-- work history -->
    <hr> 
    <div class="educational-background">
        <div class="title">
            <?php if( isset( $eb_icon ) && $eb_icon!= '' ): ?>
                <div class="icons" style="color: <?php echo ( isset( $eb_icon_color ) && $eb_icon_color != '') ? esc_attr( $eb_icon_color ) : ''?>;">
                    <i class="<?php echo esc_attr( $eb_icon ); ?>" aria-hidden="true"></i>
                </div>
            <?php endif; ?>                                  
            <?php echo ( isset($eb_label) && $eb_label != '' ) ? '<h3>' . esc_html( $eb_label . ':' ) . '</h3>' : ''; ?>
        </div>
        <div class="sub-content">
            <?php for( $i = 0; $i< sizeof($resume_education); $i++):  ?>
                <div class="education">
                    <h5><?php echo ( $resume_education[$i]['institute_name'] != '' ) ? esc_html($resume_education[$i]['institute_name']) : '' ?></h5>
                    <p><?php echo ( $resume_education[$i]['duration'] != '' ) ? esc_html($resume_education[$i]['duration']) : '' ?></p>
                </div>
                <?php if( $i < sizeof($resume_education)-1 ): ?>
                        <hr>
                <?php endif;?>
            <?php endfor; ?>            
        </div>
    </div>
    <hr>
    <div class="language-proficiency">
        <div class="title">
            <?php if( isset( $lp_icon ) && $lp_icon!= '' ): ?>
                <div class="icons" style="color: <?php echo ( isset( $lp_icon_color ) && $lp_icon_color != '') ? esc_attr( $lp_icon_color ) : ''?>;">
                    <i class="<?php echo esc_attr( $lp_icon ); ?>" aria-hidden="true"></i>
                </div>
            <?php endif; ?>                                  
            <?php echo ( isset($lp_label) && $lp_label != '' ) ? '<h3>' . esc_html( $lp_label . ':' ) . '</h3>' : ''; ?>
        </div>
        <div class="sub-content">
            <ul class="list-inline">
                <?php for( $i = 0; $i< sizeof($resume_language); $i++):  ?>
                <li>
                    <h5><?php echo ( $resume_language[$i]['bar_title'] != '' ) ? esc_html($resume_language[$i]['bar_title']) : '' ?></h5>
                    <?php 
                    $max = 5;
                    $rating = $resume_language[$i]['bar_value'];
                    if( !empty( $rating ) ) :
                        if( $max == NULL ) {
                            $max = 5;
                        }
                        if( is_float( $rating ) ) {
                            $rating = preg_replace( '/\.?0+$/', '', (int)$rating );
                        }
                        $empty_rating = $max - $rating;
                        if( is_float( $empty_rating ) ) {
                            $filled = floor( $rating );
                            $half = 1;
                            $empty = floor($empty_rating);
                        } else {
                            $filled = $rating;
                            $half = 0;
                            $empty = $empty_rating;
                        }

                        if( $max < $filled ) {
                            $filled = $max;
                        }
                        if( !ctype_digit( strval( $empty ) ) ) {
                            $empty = 0;
                        }

                        $ssr_html = '<ul>';
                        $ssr_html .= str_repeat( '<li><i class="fa fa-star" aria-hidden="true"></i></li>', (int)$filled );
                        $ssr_html .= str_repeat( '<li><i class="fa fa-star-half-o" aria-hidden="true"></i></li>', $half );
                        $ssr_html .= str_repeat( '<li><i class="fa fa-star-o" aria-hidden="true"></i><li>', $empty );
                        $ssr_html .= "</ul>";
                        echo $ssr_html;
                    endif;
                    ?>
                </li>
                <?php endfor; ?>                
            </ul>
        </div>
    </div>
    <hr>
    <div class="expertise">
        <div class="title">
            <?php if( isset( $exp_icon ) && $exp_icon!= '' ): ?>
                <div class="icons" style="color: <?php echo ( isset( $exp_icon_color ) && $exp_icon_color != '') ? esc_attr( $exp_icon_color ) : ''?>;">
                    <i class="<?php echo esc_attr( $exp_icon ); ?>" aria-hidden="true"></i>
                </div>
            <?php endif; ?>                                  
            <?php echo ( isset($exp_label) && $exp_label != '' ) ? '<h3>' . esc_html( $exp_label . ':' ) . '</h3>' : ''; ?>
        </div>                            
        <div class="sub-content">
            <div class="row">
            <?php for( $i = 0; $i< sizeof($resume_expertise); $i++):  ?>
                <div class="col-sm-4">
                    <div class="expertise-rating-bar">
                        <label><?php echo ( $resume_expertise[$i]['expertise_title'] != '' ) ? esc_html($resume_expertise[$i]['expertise_title']) : '' ?></label>
                        <div class="skill-progress">
                            <div class="progress">
                                <div class="progress-bar" role="progressbar" aria-valuenow="<?php echo ( $resume_expertise[$i]['expertise_value'] != '' ) ? esc_html($resume_expertise[$i]['expertise_value']) : '' ?>" aria-valuemin="0" aria-valuemax="100" >
                                </div>
                            </div>
                        </div>
                    </div>                                
                </div>
            <?php endfor; ?>
            </div><!-- row -->                                    
        </div>
    </div><!-- expertise -->
    <hr>
    <div class="personal-info">
        <div class="title">
            <?php if( isset( $pr_icon ) && $pr_icon!= '' ): ?>
                <div class="icons" style="color: <?php echo ( isset( $pr_icon_color ) && $pr_icon_color != '') ? esc_attr( $pr_icon_color ) : ''?>;">
                    <i class="<?php echo esc_attr( $pr_icon ); ?>" aria-hidden="true"></i>
                </div>
            <?php endif; ?>                                  
            <?php echo ( isset($pr_label) && $pr_label != '' ) ? '<h3>' . esc_html( $pr_label . ':' ) . '</h3>' : ''; ?>
        </div>  
        <div class="sub-content">
            <ul class="address">
            <?php for( $i = 0; $i< sizeof($resume_personal_info); $i++):  ?>
                <li><h5><?php echo ( $resume_personal_info[$i]['personal_info_title'] != '' ) ? esc_html($resume_personal_info[$i]['personal_info_title']) : '' ?> </h5> <span>:</span><?php echo ( $resume_personal_info[$i]['personal_info_desc'] != '' ) ? esc_html($resume_personal_info[$i]['personal_info_desc']) : '' ?></li>
            <?php endfor; ?>
            </ul>
        </div>                                
    </div><!-- personal info -->
    <hr>
    <div class="portfolio">
        <div class="title">
            <?php if( isset( $port_icon ) && $port_icon!= '' ): ?>
                <div class="icons" style="color: <?php echo ( isset( $port_icon_color ) && $port_icon_color != '') ? esc_attr( $port_icon_color ) : ''?>;">
                    <i class="<?php echo esc_attr( $port_icon ); ?>" aria-hidden="true"></i>
                </div>
            <?php endif; ?>                                  
            <?php echo ( isset($port_label) && $port_label != '' ) ? '<h3>' . esc_html( $port_label . ':' ) . '</h3>' : ''; ?>
        </div> 
        <div class="sub-content">
            <ul>
            <?php for( $i = 0; $i< sizeof($resume_portfolio); $i++):  ?>
                <li><h5><?php echo ( $resume_portfolio[$i]['portfolio_title'] != '' ) ? esc_html($resume_portfolio[$i]['portfolio_title']) : '' ?> </h5> <span>:</span><a href="<?php echo ( $resume_portfolio[$i]['portfolio_url_link'] != '' ) ? esc_url($resume_portfolio[$i]['portfolio_url_link']) : '' ?>"><?php echo ( $resume_portfolio[$i]['portfolio_url_text'] != '' ) ? esc_html($resume_portfolio[$i]['portfolio_url_text']) : '' ?></a></li>
            <?php endfor; ?>
            </ul>                                    
        </div>                                
    </div><!-- portfolio -->
    <hr>
    <div class="declaration">
        <div class="title">
            <?php if( isset( $dec_icon ) && $dec_icon!= '' ): ?>
                <div class="icons" style="color: <?php echo ( isset( $dec_icon_color ) && $dec_icon_color != '') ? esc_attr( $dec_icon_color ) : ''?>;">
                    <i class="<?php echo esc_attr( $dec_icon ); ?>" aria-hidden="true"></i>
                </div>
            <?php endif; ?>                                  
            <?php echo ( isset($dec_label) && $dec_label != '' ) ? '<h3>' . esc_html( $dec_label . ':' ) . '</h3>' : ''; ?>
        </div>
        <div class="sub-content">
            <p><?php echo $content; ?> </p>
            <div class="signature">
                <h1><?php echo ( $resume_signature != '' ) ? esc_html($resume_signature) : '' ?> </h1>
            </div>                                    
        </div>                                 
    </div>
</div>
<div class="button">
    <a href="<?php echo ( $resume_pdf != '' ) ? esc_url($resume_pdf) : '' ?>" target="_blank" class="btn btn-primary">Download My Resume as a .pdf file</a>
</div>
<?php  return ob_get_clean();
}
